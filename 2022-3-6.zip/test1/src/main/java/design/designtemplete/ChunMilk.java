package design.designtemplete;

public class ChunMilk extends Milk{
    @Override
    protected void operate1() {

    }

    @Override
    protected void operate2() {

    }

}
