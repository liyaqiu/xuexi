package design.designadpater;

public interface Adpater {
    public Doctor getDocker(Animal animal);
}
