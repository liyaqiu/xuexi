package socket.bio.tcp.test3;

public class Son extends Father {
    @Override
    public void haha() {
        super.haha();
//        System.out.println("你好" + Thread.currentThread().getName());
//        try {
//            Thread.sleep(Integer.MAX_VALUE);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
    }
}
