package com.dao;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

/**
 * @author lyq
 * @date 2022/2/25 7:58
 */
@Slf4j
@Repository
public class MyUserDao {


}
