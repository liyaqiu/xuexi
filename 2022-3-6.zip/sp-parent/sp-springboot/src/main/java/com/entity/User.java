package com.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import org.springframework.stereotype.Component;

/**
 * @author lyq
 * @date 2021/12/5 12:27
 */
@Data
@Component
public class User{
    private String id;
    private String name;
    private Integer age;


}
