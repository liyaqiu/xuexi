package design.designproxy.dynamicproxyjdk;

public interface ICar {
    public abstract void run();
    public abstract String run(String s);
    //public void test0();
}
