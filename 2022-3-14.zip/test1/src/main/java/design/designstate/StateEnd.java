package design.designstate;

//开始状态
public class StateEnd extends AbsState{

    public StateEnd(PrizePool prizePool) {
        super(prizePool);
    }


}
