package design.designadpater;

public class Dog implements Animal{
}
