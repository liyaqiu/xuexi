package design.designadpater;

public interface Animal {
}
