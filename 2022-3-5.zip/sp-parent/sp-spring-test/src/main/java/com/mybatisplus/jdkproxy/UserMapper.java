package com.mybatisplus.jdkproxy;

public interface UserMapper {
    public abstract void insert();
    public abstract int delete(String s);
    public abstract int update(String s);
    public abstract int select(String s);
}
