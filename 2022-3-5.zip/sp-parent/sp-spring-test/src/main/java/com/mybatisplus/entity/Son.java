package com.mybatisplus.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author lyq
 * @date 2022/3/5 9:31
 */
@Getter
@Setter
@ToString
public class Son {
    private String sid;
    private String sname;
    private Integer sage;
}
