package com.aop.jdk.proxyobj;

/**
 * @author lyq
 * @date 2022/3/2 2:39
 */
public interface Target {
    void sayHello();
}
