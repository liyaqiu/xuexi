package logslf4j2;


import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Slf4j
public class Slf4jTest {

    final static Logger logger = LoggerFactory.getLogger(Slf4jTest.class);
    public static void main(String[] args) {

    }
    @Test
    public  void test02() throws InterruptedException {
        logger.error("姓名:{{}},年龄{{}}","李雅秋",1);
        logger.warn("姓名:{{}},年龄{{}}","李雅秋",1);
        logger.info("姓名:{{}},年龄{{}}","李雅秋",1);
        logger.debug("姓名:{{}},年龄{{}}","李雅秋",1);
        logger.trace("姓名:{{}},年龄{{}}","李雅秋",1);
    }
    @Test
    public  void test01() throws InterruptedException {
        for (int i = 0; i < 100000; i++) {
            Thread.sleep(1000);
            logger.error("姓名:{{}},年龄{{}}","李雅秋",i);
            logger.warn("姓名:{{}},年龄{{}}","李雅秋",i);
            logger.info("姓名:{{}},年龄{{}}","李雅秋",i);
            logger.debug("姓名:{{}},年龄{{}}","李雅秋",i);
            logger.trace("姓名:{{}},年龄{{}}","李雅秋",i);
        }
    }
}
