package thread.newtest;

import java.io.Serializable;

public class Haha implements Serializable {
    public String abc;
}
