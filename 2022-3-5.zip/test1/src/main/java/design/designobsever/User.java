package design.designobsever;

public interface User {

    void receive(String msg);

}
