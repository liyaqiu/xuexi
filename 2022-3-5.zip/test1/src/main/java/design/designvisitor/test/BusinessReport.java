package design.designvisitor.test;

import java.util.LinkedList;
import java.util.List;

// 员工业务报表类
public class BusinessReport {

    private List<Staff> mStaffs = new LinkedList<>();

    public BusinessReport() {
        mStaffs.add(new ManagerStaff("经理-A"));
        mStaffs.add(new EngineerStaff("工程师-A"));
        mStaffs.add(new EngineerStaff("工程师-B"));
        mStaffs.add(new EngineerStaff("工程师-C"));
        mStaffs.add(new ManagerStaff("经理-B"));
        mStaffs.add(new EngineerStaff("工程师-D"));
    }

    /**
     * 为访问者展示报表
     * @param visitor 公司高层，如CEO、CTO
     */
    public void showReport(Visitor visitor) {
        for (Staff staff : mStaffs) {
            staff.accept(visitor);
        }
    }
}