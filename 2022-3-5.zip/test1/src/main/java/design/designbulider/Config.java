package design.designbulider;

public interface Config {
}
