package design.designproxy.cglib.demo;

public class UserMapper {
    public  void insert(){}
    public  int delete(String id){return 1;};

}
