package design.designadpater;

public class CatDocter implements Doctor{
    @Override
    public void kanbing() {
        System.out.println("给猫看病");
    }
}
