package log.jcl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.helpers.LogLog;
import org.junit.Test;

/**
 * jcl门面技术
 * */
public class JCLTest {
    @Test
    public void test01(){
        LogLog.setInternalDebugging(true);
        Log log = LogFactory.getLog(JCLTest.class);
        log.error("你好...");

    }
}
