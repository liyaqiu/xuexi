package sp.caffeine.mycache;

/**
 * @author lyq
 * @date 2022/2/23 23:44
 */
public class CacheBean {
    long expireTime;
}
