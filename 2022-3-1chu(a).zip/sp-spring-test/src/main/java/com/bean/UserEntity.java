package com.bean;

import lombok.Data;

/**
 * @author lyq
 * @date 2022/2/27 1:07
 */
@Data
public class UserEntity {
    private String name = "hello";
}
