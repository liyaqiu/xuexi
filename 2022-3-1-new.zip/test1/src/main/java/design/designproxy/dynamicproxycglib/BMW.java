package design.designproxy.dynamicproxycglib;

//不能为final类
public class BMW {

    public static final void run() {
        System.out.println("静态或者final类都不会被拦截到");
    }

    public synchronized String run(String name){
        System.out.println(name + "在奔跑");
        return name;
    }
}
