package design.designproxy.staticproxy;

import java.util.List;

public interface ICar {
    List<String> run();
}
