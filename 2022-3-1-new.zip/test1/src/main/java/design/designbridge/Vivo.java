package design.designbridge;

public class Vivo implements Supplier{
    @Override
    public String getSupplier() {
        return "Vivo";
    }
}
