package design.designbridge;

public interface Supplier {
     String getSupplier();

}
