package logtest.slf4j;


import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SimpleTest {

    final static Logger logger = LoggerFactory.getLogger(SimpleTest.class);
    @Test
    public  void test01() {
        try {
            logger.debug("姓名:{{}},年龄{{}}","李雅秋",12);
        } catch (Exception e) {
        }
    }
}
