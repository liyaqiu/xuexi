package com.sp.entity;

import lombok.Data;

/**
 * @author lyq
 * @date 2022/1/9 18:55
 */
@Data
public class UserEntity {
    private String name;
    private String age;
}
