package com.entity;

import lombok.Getter;
import lombok.Setter;

/**
 * @author eric
 * @date 2022/4/19 15:19
 **/
@Getter
@Setter
public class UserEntity {
    String username;
    String passwd;
}
