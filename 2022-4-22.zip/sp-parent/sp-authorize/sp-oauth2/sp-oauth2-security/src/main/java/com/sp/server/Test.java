package com.sp.server;

import javax.servlet.*;
import java.io.IOException;

/**
 * @author eric
 * @date 2022/3/21 15:55
 **/
public class Test implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        
    }

    @Override
    public void destroy() {

    }
}
