package design.designtemplete;

public interface IMilk {
    public void operate();
}
