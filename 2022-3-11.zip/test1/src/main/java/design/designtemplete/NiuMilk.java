package design.designtemplete;

public class NiuMilk extends Milk{
    @Override
    protected void operate1() {
        System.out.println("操作1");
    }

    @Override
    protected void operate2() {
        System.out.println("操作2");
    }
}
