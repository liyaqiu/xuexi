package design.designdecorator;

public abstract class Pack {
  protected abstract void toPack();
}
