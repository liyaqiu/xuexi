package design.designiterator;

public class Test {
    public static void main(String[] args) {
//        List<PersonalBean> list = new ArrayList<>();
//        list.add(new PersonalBean("张三"));
//        list.add(new PersonalBean("李四"));
//        list.add(new PersonalBean("王五"));
//        Iterator<PersonalBean> personalIterator = new PersonalIterator(list);
//        while (personalIterator.hasNext()){
//            System.out.println(personalIterator.next());
//        }



    }
}
