package com.service;

/**
 * @author lyq
 * @date 2021/7/8 0:41
 */
public class ZmsService {
    public void test01(){
        System.out.println("nihao");

    }
    public void test02(){
        System.out.println("hello");
    }
    public void test03(){
        System.out.println("hey..");
    }
    public void test04(){
        System.out.println("release...");
    }
    public void test05(){
        System.out.println("");
    }

}
