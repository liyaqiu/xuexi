package com.aop.jdk.proxyobj2;

/**
 * @author lyq
 * @date 2022/3/2 2:39
 */
public interface Target2 {
    void sayHello();
}
