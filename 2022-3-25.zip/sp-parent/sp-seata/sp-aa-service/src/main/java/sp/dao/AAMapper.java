package sp.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import sp.entity.AAEntity;

/**
 * @author lyq
 * @date 2022/1/22 6:51
 */
@Mapper
public interface  AAMapper extends BaseMapper<AAEntity> {
}
