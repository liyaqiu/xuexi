package com.config;

import lombok.ToString;
import org.springframework.stereotype.Component;

/**
 * @author lyq
 * @date 2022/3/8 17:40
 */
@Component
@ToString
public class TestConfig {
    String name = "liyaqiu";
}
