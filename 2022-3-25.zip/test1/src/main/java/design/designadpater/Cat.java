package design.designadpater;

public class Cat implements Animal{
}
