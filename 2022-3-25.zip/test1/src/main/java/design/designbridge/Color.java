package design.designbridge;

public interface Color {
    String getColor();
}
