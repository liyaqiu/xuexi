package com.sp.spring_security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.AdviceMode;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;

/**
 * @author eric
 * @date 2022/3/19 15:02
 **/
@Slf4j
@Configuration(proxyBeanMethods = false)
//@EnableGlobalMethodSecurity(securedEnabled =true,prePostEnabled = true) //启用方法权限配置
public class SecurityConfig extends WebSecurityConfigurerAdapter {


    //认证数据与
    //@Bean
    public UserDetailsService infoDatabase(){
        log.info("infoDatabase");
        return new UserDetailsService() {
            @Override
            public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
                log.info("loadUserByUsername {}",username);

                if (username == null) {
                    throw new UsernameNotFoundException(username);
                }
                //数据库接入
                return User.withUsername("liyaqiu").password("123456").authorities("resource1Permission","p1").disabled(false).accountLocked(false).build();
            }
        };


//        UserDetailsManager manager = new InMemoryUserDetailsManager();
//        manager.createUser(User.withUsername("liyaqiu").password("123456").authorities("resource1Permission").build());
//        manager.createUser(User.withUsername("eric").password("123456").authorities("resource2Permission").build());
//        return manager;
    }


    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        log.info("AuthenticationManagerBuilder auth configure111111111111111111111");
        //auth.inMemoryAuthentication().withUser("eric").password("123456").authorities("resource2Permission");
        auth.userDetailsService(infoDatabase()).passwordEncoder(passwordEncoder());
    }

    //密码编码器
    //@Bean
    public PasswordEncoder passwordEncoder(){
        log.info("passwordEncoder");
        return NoOpPasswordEncoder.getInstance();
        //return new BCryptPasswordEncoder();
    }


    //拦截机制
    /*
    *AccessDecisionManager  投票策略接口
    * */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        log.info("拦截机制");
        http.csrf().disable().authorizeRequests()
                .antMatchers("/security/resource1").hasAuthority("resource2Permission")//授权认证
                .antMatchers("/security/resource1").hasAuthority("resource1Permission")//授权认证
                .antMatchers("/security/resource2").hasAuthority("resource2Permission")//授权认证
                .antMatchers("/security/**").authenticated()//认证
                .anyRequest().permitAll() //permitAll 放行全部资源
                .and() //登录管理
                    .formLogin() //设置表单登录
                    //.loginPage("https://www.baidu.com")
                    //设置登录页面地址
                    //.loginPage("/login-dir/login1.html")
                    .loginPage("/loginpage")
                    //设置提交用户名参数
                    .usernameParameter("name")
                    //设置提交密码参数
                    .passwordParameter("pass")
                    //设置表单提交的地址
                    .loginProcessingUrl("/submitlogin")
                    //设置成功够转发的地址
                    .successForwardUrl("/success")
                    //permitAll 放行全部资源
                    .permitAll()
                .and()//退出
                    .logout()
                    .logoutUrl("/mylogout")
                    .logoutSuccessUrl("/out")
                    .permitAll()
                .and()//会话管理
                    .sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)//单体应用利用session来保存，如果没有session就创建
                    //.invalidSessionUrl("/login-dir/login1.html") //session过去调转的url
                ;

    }
}
