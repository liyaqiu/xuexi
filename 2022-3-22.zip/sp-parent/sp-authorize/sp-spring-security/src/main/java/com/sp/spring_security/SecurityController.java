package com.sp.spring_security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

/**
 * @author eric
 * @date 2022/3/19 12:45
 **/
@Slf4j
@RestController
public class SecurityController {

//    @GetMapping("/security/helloworld")
//    @PreAuthorize("hasAuthority('p2')")
//    public String helloworld(){
//        log.info("helloworld");
//        return "helloworld";
//    }


    @GetMapping("/security/resource1")
    public String resource1(){
        log.info("resource1");
        return "资源1访问成功";
    }

    @GetMapping("/security/resource2")
    public String resource2(){
        log.info("resource2");
        return "资源2访问成功";
    }


    @RequestMapping("/loginpage")
    public Map<String,String> loginpage(HttpSession session){
        log.info("loginpage");
        Map<String,String> map = new HashMap<>();
        map.put("state", "403");
        map.put("message", "no login");
        return map;
    }
    @RequestMapping("/success")
    public String success(HttpSession session){
        log.info("success");
        return getUserName()+"登陆成功";
    }
    @RequestMapping("/out")
    public String out(HttpSession session){
        log.info("out");
        return getUserName()+"退出成功";
    }

    /**
     * 获取用户名
     * */
    public String getUserName(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if(!authentication.isAuthenticated()){
            return null;
        }
        Object principal = authentication.getPrincipal();
        if(principal instanceof UserDetails){
             return  ((UserDetails)principal).getUsername();
        }
        if(principal!=null){
            return principal.toString();
        }
        return null;
    }
}
