package datastruct.find;

import java.util.Arrays;

public class FeiBoNaQiFind {
    public static void main(String[] args) {

    }
}
