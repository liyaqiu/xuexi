package design.designadpater;

public class DogDoctor implements Doctor{
    @Override
    public void kanbing() {
        System.out.println("给狗看病");
    }
}
