package design.designbridge;

public class GreenColor implements Color{
    @Override
    public String getColor() {
        return "绿色";
    }
}
