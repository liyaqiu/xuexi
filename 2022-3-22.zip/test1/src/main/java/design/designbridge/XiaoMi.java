package design.designbridge;

public class XiaoMi implements Supplier{
    @Override
    public String getSupplier() {
        return "小米厂家";
    }
}
