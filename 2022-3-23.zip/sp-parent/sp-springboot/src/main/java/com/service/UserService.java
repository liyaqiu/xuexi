package com.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.entity.User;

/**
 * @author lyq
 * @date 2021/12/6 12:39
 */
public interface UserService  extends IService<User> {
}
