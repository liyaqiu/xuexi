package com.acl.secure;


import com.acl.common.config.EnableCommonConfig;
import com.acl.common.utils.JWTTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * @author lyq
 * @date 2021/12/4 12:34
 */
@SpringBootApplication
@EnableCommonConfig
public class SecureApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(SecureApplication.class, args);
    }


}
