package com.acl.secure.handler;

import com.acl.common.utils.JWTTokenUtil;
import com.acl.common.utils.ResultUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author eric
 * @date 2022/3/23 18:25
 **/
@Component
public class MyLogoutHandler implements LogoutHandler {

    @Autowired
    StringRedisTemplate redisTemplate;

    @Override
    public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
        String token = request.getHeader("token");
        if(token!=null){
            String userName = JWTTokenUtil.tokenParse(token);
            //从redis上删除key
            redisTemplate.delete(userName);
        }
        try {
            response.getWriter().write(ResultUtil.okJson());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
