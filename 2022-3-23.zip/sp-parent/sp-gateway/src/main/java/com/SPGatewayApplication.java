package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author lyq
 * @date 2022/1/11 0:29
 */
@SpringBootApplication
public class SPGatewayApplication {
    public static void main(String[] args) {
        SpringApplication.run(SPGatewayApplication.class, args);
    }
}
