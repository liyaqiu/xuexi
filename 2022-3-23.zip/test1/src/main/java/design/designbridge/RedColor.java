package design.designbridge;

public class RedColor implements Color{
    @Override
    public String getColor() {
        return "红色";
    }
}
