package design.designadpater;

public interface Doctor {
    void kanbing();
}
